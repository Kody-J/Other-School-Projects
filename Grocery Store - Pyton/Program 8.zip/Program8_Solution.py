import copy


class Customer(object):
    """ Simulates a customer in a queue """

    def __init__(self, cust_number: int, arrived: int, items: int):
        """ This method initializes the variables for the instance of the Customer instance
        :param cust_number  : int - The number of the customer
        :param arrived      : int - The time the customer arrived
        :param items        : int - How many items they've purchased.
        :return             : None

        The __init__ also initializes other attributes that aren't passed in.
        items_paid          : int - How many items have been paid for.
            Starts out at zero and as the checker checks them out it gets incremented.
        line_arrival        : int - Initializes to None, but is the time they arrive at the line.
        line_exit           : int - The clock time they exited the line.  Initially should be None
        cashier_arrival     : int - The time they arrived at the cashier.  Initially should be None
        cashier_exit        : int - The time they left the cashier.  Initially should be None
        """
        pass  # Put your code here.

    def __str__(self):
        """ String Representation
        :return             : str - Returns the string representation of the customer instance.

        It should be in the form C(1)  Where 1 is the number of the customer.
        """
        return ""

    def __repr__(self):
        """ String Representation of the instance
        :return             : str -  Returns the string representation of the customer instance.
        """
        return ""

    def get_in_line(self, clock):
        """ Method sets the arrival time to the clock.
        :param clock        : int - The time as an int when the person gets into line.
        :return             : None
        """
        pass  # Put your code here.

    def at_cashier(self, clock):
        """  Method is called when the customer gets to the cashier.
        :param clock        : int - The time the customer got to the cashier.
        :return             : None
         It should set the line_exit attribute and cashier_arrival attribute
        """
        pass  # Put your code here.

    def exit_cashier(self, clock):
        """ Method is called when the customer exists the cashier.
        :param clock        : int - The time the customer got to the cashier.
        :return             : None
         Sets the cashier_exit attribute
        """
        pass  # Put your code here.

    def update(self, clock):
        """ Method is called for each update at the clock.  If the customer has arrived at the cashier and has items
            Then their items get decremented and items_paid is incremented. ( an item got scanned ).
        :param clock        : int - The time the customer got to the cashier.
        :return             : None
        """
        pass   # Put your code here

    def wait_time(self):
        """ Method returns how long the customer has waited.
        The difference from when they left the line and when they entered it
         If they haven't arrived in a line or exited the line then it should return None
        :return             : int - The time they waited in line.
        """
        pass   # Put your code here.

class Cashier(object):
    """ Simulates a cashier """
    def __init__(self, lane : int, line : iter, exit_pool : iter):
        """ Initializes the Cashier
        :param lane         : int - The lane of the cashier.  1, 2, 3, etc
        :param line         : list - Iterable that is the line of customers waiting.
        :param exit_pool    : list - All custoemrs leave the cashier into an exit pool.  We can then examine our
                                customers in the exit pool to see how long they waited.
        :return             : None
        """
        pass   # Put your code here.

    def __str__(self):
        """ String Representation of Cashier
        :return             : str - Returns the string representation of the Register instance.

        It should be in the form $(1)  Where 1 is the number of the Lane
                If the Cashier has a customer in it then it should be $(1) - C(1)  ( followed by the customer )
        """
        return ""       # Put your code and returns in.

            
    def update(self, clock):
        """ updates the world for every clock tick.
        :param clock        : int - The clock time of when the update occurs.
        :return             : None
        If the cashier has a customer then it updates the customer until all the items are paid for
            If the customer has all the items paid for then
                they leave and hit the exit pool
                We get another customer from the line assuming there is one.
        If there is no customer then we get one from our line assuming that their is one.

        """
        pass   # Put your code here.

    def is_empty(self):
        """ Returns if there is none at the register either in line or being checked out.
        :return             : bool True if their is no customer checking out and the line is empty.
        """
        pass   # Put your code here.


# You may need some helper functions.

# If the name of module running is the main module and isn't being imported run it.
if __name__ == "__main__":
    pass   # Put your main program code here.
